Inteligencia Artificial - Sistemas Basados en el Conocimiento

* DOCS:
   * informe.pdf
   
* FONT:
    * ontologia:
        * ontologia.dot  --> grafo de la ontolog�a
        * ontologia.pins --> instancias
        * ontologia.pont --> clases de la ontolog�a
        * ontologia.pprj --> proyecto de la ontolog�a en Prot�g�
    * src:
        * consultas.clp --> m�dulo de entrada de alumno
        * respref.clp --> m�dulo de entrada de restricciones/preferencias e inferencia
        * abstraccion.clp --> m�dulo de abstracci�n de datos
        * asociacion.clp --> m�dulo de asociaci�n heur�stica
        * refinamiento.clp --> m�dulo de refinamiento y m�dulo de soluci�n
        
        * main.bat --> m�todo r�pido para ejecutar en CLIPS el SBC
        

        
Para ejecutar en CLIPS el SBC solo hay que hacer:
    File >> Load Batch... y seleccionar el archivo main.bat
 